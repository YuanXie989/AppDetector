# App Detector (Android)

A transparent, consent-based family device monitor prototype.

## What it detects
- Newly installed apps via Android `ACTION_PACKAGE_ADDED` broadcasts (updates are ignored).
- APK files in a folder the device owner explicitly selects through Android's Storage Access Framework.
- Local event history and user-visible notifications.

## Important limitations
- APK scans are periodic (WorkManager, typically no more often than every 15 minutes), not instant.
- Only the selected folder and its subfolders (up to 3 levels) are scanned. It cannot see every app/browser's private download location.
- Android does not provide a universal API for silently observing every download from every app.
- The app does not capture browsing history, messages, passwords, or app activity.
- `QUERY_ALL_PACKAGES` is included to resolve app labels for installed-package events. Google Play heavily restricts this permission; this prototype is intended for private family sideloading and must be installed with the device owner's knowledge and consent.
- Android OEM battery restrictions may delay background scans.

## Build
1. Open this folder in Android Studio (Hedgehog or newer).
2. Use JDK 17 and allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK on the family device with the owner's consent.
5. Open App Detector, grant notifications, and choose the Downloads folder (or a folder where APKs are saved).

Package: `com.example.appdetector`
Min Android: 8.0 (API 26)
Target SDK: 35
