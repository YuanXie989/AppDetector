package com.example.appdetector

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object ActivityLog {
    private const val PREFS = "activity_log"
    private const val KEY = "events"

    @Synchronized fun add(context: Context, type: String, title: String, detail: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = JSONArray(prefs.getString(KEY, "[]"))
        val item = JSONObject().apply {
            put("type", type); put("title", title); put("detail", detail)
            put("time", System.currentTimeMillis())
        }
        val next = JSONArray().put(item)
        // Keep a compact local history (latest 250 entries).
        for (i in 0 until minOf(old.length(), 249)) next.put(old.getJSONObject(i))
        prefs.edit().putString(KEY, next.toString()).apply()
    }

    fun all(context: Context): JSONArray = JSONArray(
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]")
    )

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }
}
