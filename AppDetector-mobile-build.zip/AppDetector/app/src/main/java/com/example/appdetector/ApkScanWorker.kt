package com.example.appdetector

import android.content.Context
import androidx.documentfile.provider.DocumentFile
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class ApkScanWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)
        val tree = prefs.getString("downloads_tree", null) ?: return Result.success()
        val root = try { DocumentFile.fromTreeUri(applicationContext, android.net.Uri.parse(tree)) } catch (_: Exception) { null }
            ?: return Result.success()
        val known = prefs.getStringSet("seen_apks", emptySet())?.toMutableSet() ?: mutableSetOf()
        val found = mutableListOf<DocumentFile>()
        scan(root, found, 0)
        val firstScan = !prefs.getBoolean("apk_baseline_done", false)
        var changed = false
        for (file in found) {
            val uri = file.uri.toString()
            if (known.add(uri)) {
                changed = true
                // Existing APKs are registered quietly on the first scan, not reported as new downloads.
                if (!firstScan) {
                    val name = file.name ?: "file.apk"
                    ActivityLog.add(applicationContext, "apk", name, "APK baru terdeteksi di folder yang dipilih • ${file.length()} byte")
                    Notify.show(applicationContext, "File APK baru terdeteksi", name)
                }
            }
        }
        if (changed || firstScan) prefs.edit().putStringSet("seen_apks", known).putBoolean("apk_baseline_done", true).apply()
        return Result.success()
    }

    private fun scan(dir: DocumentFile, out: MutableList<DocumentFile>, depth: Int) {
        if (depth > 3) return
        try {
            for (f in dir.listFiles()) {
                if (f.isDirectory) scan(f, out, depth + 1)
                else if (f.isFile && f.name?.endsWith(".apk", ignoreCase = true) == true) out.add(f)
            }
        } catch (_: SecurityException) { }
    }
}
