package com.example.appdetector

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var content: LinearLayout
    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            getSharedPreferences("settings", MODE_PRIVATE).edit().putString("downloads_tree", uri.toString()).apply()
            getSharedPreferences("settings", MODE_PRIVATE).edit().putStringSet("seen_apks", emptySet()).putBoolean("apk_baseline_done", false).apply()
            scheduleScan()
            refresh()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 28, 24, 24) }
        val scroll = ScrollView(this).apply { addView(content) }
        setContentView(scroll)
        scheduleScan()
        refresh()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
    }

    private fun scheduleScan() {
        val request = PeriodicWorkRequestBuilder<ApkScanWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("apk_folder_scan", ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    private fun refresh() {
        content.removeAllViews()
        text("APP DETECTOR", 28f, true)
        text("Pemantauan transparan untuk perangkat keluarga", 14f, false)
        text("Status pemantauan", 19f, true)
        val folder = getSharedPreferences("settings", MODE_PRIVATE).getString("downloads_tree", null)
        text(if (folder == null) "Folder APK belum dipilih" else "Folder APK sudah dipilih", 15f, true)
        button("Pilih folder Download / APK") { folderPicker.launch(null) }
        button("Periksa APK sekarang") {
            WorkManager.getInstance(this).enqueue(androidx.work.OneTimeWorkRequestBuilder<ApkScanWorker>().build())
            text("Pemindaian diminta. Hasil akan muncul di riwayat.", 13f, false)
        }
        button("Segarkan riwayat") { refresh() }
        button("Hapus riwayat lokal") { ActivityLog.clear(this); refresh() }
        text("RIWAYAT AKTIVITAS", 19f, true)
        val events = ActivityLog.all(this)
        if (events.length() == 0) text("Belum ada aktivitas yang terdeteksi.", 14f, false)
        for (i in 0 until events.length()) {
            val e = events.getJSONObject(i)
            val time = DateFormat.getDateTimeInstance().format(Date(e.optLong("time")))
            val kind = if (e.optString("type") == "installed") "APLIKASI TERPASANG" else "APK DIUNDUH / DITEMUKAN"
            text("$kind\n${e.optString("title")}\n${e.optString("detail")}\n$time", 14f, false)
            text("────────────────────────", 12f, false)
        }
        text("Catatan: pemantauan APK hanya mencakup folder yang kamu pilih. Pemindaian berjalan berkala (minimal sekitar 15 menit, tergantung Android).", 12f, false)
    }

    private fun text(value: String, size: Float, bold: Boolean) {
        val t = TextView(this).apply { text = value; textSize = size; setPadding(0, 8, 0, 8); if (bold) setTypeface(null, android.graphics.Typeface.BOLD) }
        content.addView(t)
    }
    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply { text = label; setOnClickListener { action() } }
        content.addView(b)
    }
}
