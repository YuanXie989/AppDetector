package com.example.appdetector

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import java.text.DateFormat
import java.util.Date

class PackageEventReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_PACKAGE_ADDED) return
        val packageName = intent.data?.schemeSpecificPart ?: return
        // Replacing/updating an existing app is not treated as a newly installed app.
        if (intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)) return
        val label = try {
            val info = if (Build.VERSION.SDK_INT >= 33)
                context.packageManager.getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(0))
            else @Suppress("DEPRECATION") context.packageManager.getApplicationInfo(packageName, 0)
            context.packageManager.getApplicationLabel(info).toString()
        } catch (_: Exception) { packageName }
        val whenText = DateFormat.getDateTimeInstance().format(Date())
        ActivityLog.add(context, "installed", label, "$packageName • $whenText")
        Notify.show(context, "Aplikasi baru dipasang", "$label ($packageName)")
    }
}
